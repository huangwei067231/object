<template>
  <footer>
    <p>© xiedaimala.com 2018 wechat: xiedaimala01</p>
  </footer>
</template>

<style scoped>
footer {
  align-self: end;
  background-color: #d7d7d7;
  color: #666;
  font-size: 13px;
  padding: 10px;
  text-align: center;
}

</style>