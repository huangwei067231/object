export default {
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}